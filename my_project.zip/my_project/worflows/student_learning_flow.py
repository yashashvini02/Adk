from adk.core.workflow import SequentialWorkflow
from agents.repo_discovery_agent import RepoDiscoveryAgent
from agents.student_repo_analyzer_agent import StudentRepoAnalyzerAgent

class StudentLearningFlow(SequentialWorkflow):
    def __init__(self):
        super().__init__(
            name="StudentLearningFlow",
            steps=[
                RepoDiscoveryAgent(),
                StudentRepoAnalyzerAgent()
            ]
        )