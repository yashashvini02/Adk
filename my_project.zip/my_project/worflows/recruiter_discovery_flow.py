from adk.core.workflow import SequentialWorkflow
from agents.recruiter_candidate_search_agent import RecruiterCandidateSearchAgent
from agents.candidate_scoring_agent import CandidateScoringAgent

class RecruiterDiscoveryFlow(SequentialWorkflow):
    def __init__(self):
        super().__init__(
            name="RecruiterDiscoveryFlow",
            steps=[
                RecruiterCandidateSearchAgent(),
                CandidateScoringAgent()
            ]
        )
