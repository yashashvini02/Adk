import os
import requests

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
HEADERS = {"Authorization": f"token {GITHUB_TOKEN}"} if GITHUB_TOKEN else {}

def search_repositories_by_topic(topic, min_stars=0):
    url = f"https://api.github.com/search/repositories?q={topic}+stars:>{min_stars}&sort=stars&order=desc"
    response = requests.get(url, headers=HEADERS)
    items = response.json().get("items", [])
    return [{"name": r["name"], "url": r["html_url"]} for r in items[:5]]

def analyze_repo_details(repo_url):
    return {
        "repo": repo_url,
        "summary": "Example AI repo",
        "beginner_friendly": True,
        "good_first_issues": ["Issue 1", "Issue 2"],
        "skills": ["Python", "Flask"]
    }

def search_users_by_topic(topic, location=None, min_followers=0):
    query = f"{topic}+in:bio+followers:>{min_followers}"
    if location:
        query += f"+location:{location}"
    url = f"https://api.github.com/search/users?q={query}"
    response = requests.get(url, headers=HEADERS)
    items = response.json().get("items", [])
    return [{"username": u["login"], "url": u["html_url"]} for u in items[:5]]

def score_candidate_profile(user):
    username = user["username"]
    url = f"https://api.github.com/users/{username}"
    response = requests.get(url, headers=HEADERS).json()
    return {
        "username": username,
        "profile": user["url"],
        "score": int(response.get("followers", 0)) + int(response.get("public_repos", 0)),
        "skills": ["JavaScript", "React"] if "react" in response.get("bio", "").lower() else ["Python"]
    }

