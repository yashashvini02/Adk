from adk.agents import BaseAgent
from tools.github_api_tool import search_repositories_by_topic

class RepoDiscoveryAgent(BaseAgent):
    def run(self, input):
        domain = input.get("domain")
        min_stars = input.get("min_stars", 0)
        repos = search_repositories_by_topic(domain, min_stars)
        return {"repos": repos}
