from adk.agents import BaseAgent
from tools.github_api_tool import analyze_repo_details

class StudentRepoAnalyzerAgent(BaseAgent):
    def run(self, input):
        analyzed = []
        for repo in input.get("repos", []):
            result = analyze_repo_details(repo["url"])
            analyzed.append(result)
        with open("output_results.txt", "w") as f:
            for item in analyzed:
                f.write(str(item) + "\n")
        return {"analyzed_repos": analyzed}
