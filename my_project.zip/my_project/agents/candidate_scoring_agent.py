from adk.agents import BaseAgent
from tools.github_api_tool import score_candidate_profile

class CandidateScoringAgent(BaseAgent):
    def run(self, input):
        scored = [score_candidate_profile(user) for user in input.get("candidates", [])]
        with open("output_results.txt", "w") as f:
            for item in scored:
                f.write(str(item) + "\n")
        return {"scored_candidates": scored}