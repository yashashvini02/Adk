from adk.agents import BaseAgent
from tools.github_api_tool import search_users_by_topic

class RecruiterCandidateSearchAgent(BaseAgent):
    def run(self, input):
        domain = input.get("domain")
        location = input.get("location", None)
        min_followers = input.get("min_followers", 0)
        candidates = search_users_by_topic(domain, location, min_followers)
        return {"candidates": candidates}
