from adk.core.app import App
from workflows.student_learning_flow import StudentLearningFlow
from workflows.recruiter_discovery_flow import RecruiterDiscoveryFlow

app = App(
    workflows=[
        StudentLearningFlow(),
        RecruiterDiscoveryFlow()
    ]
)
